
#ifndef __DELAY_H__
#define __DELAY_H__

#include<reg51.h>

#define uchar unsigned char
#define uint unsigned int

extern void delay(uchar i);

#endif
